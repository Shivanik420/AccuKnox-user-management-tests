# Page object model for admin/user management.
