# Application Health Checker Script (Problem Statement 2 - Option 4)
