# System Health Monitoring Script (Problem Statement 2 - Option 1)
