# AccuKnox User Management Tests

## 📦 Project Setup

1. Create a virtual environment (optional but recommended):
```bash
python -m venv venv
source venv/bin/activate  # On Windows use `venv\Scripts\activate`
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Run tests:
```bash
pytest tests/
```

## 🔧 Playwright Version
This project uses Playwright for Python.

## 📁 Folder Structure
- `pages/`: Page Object Models for different pages.
- `tests/`: Test cases using pytest.
- `testcases/`: Manual test case spreadsheet.
- `scripts/`: Bash or Python scripts for Problem Statement 2.
